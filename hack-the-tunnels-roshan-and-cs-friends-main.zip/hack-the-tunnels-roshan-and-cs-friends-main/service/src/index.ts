import app from "./app";

app.start();
