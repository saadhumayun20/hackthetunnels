import "./Footer.style.scss";

function Footer() {
  return <div className="footer">2023© Roshan and C.S Friends</div>;
}

export default Footer;
