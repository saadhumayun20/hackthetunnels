const NotFound = () => {
    return(
        <div>
            <h1>404: Not Found</h1>
            <p>This page does not exist silly:(</p>
            <img src = "https://media.tenor.com/xCc58fEqFREAAAAd/nerd-nerdy.gif" />
        </div>
    );
};
export default NotFound;
