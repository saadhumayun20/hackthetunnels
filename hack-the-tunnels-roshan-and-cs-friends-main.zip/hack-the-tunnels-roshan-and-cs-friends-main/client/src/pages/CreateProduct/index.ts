export { default as CreateProduct } from "./CreateProduct";
